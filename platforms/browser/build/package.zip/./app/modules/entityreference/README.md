entityreference
===============

Adds Entity Reference support for DrupalGap.

1. Enable the "DrupalGap Entity Reference" module on your Drupal site.
   This is a sub module included with the DrupalGap module.
2. Enable this module in your settings.js file:
     Drupal.modules.contrib['entityreference'] = {};
3. See http://drupalgap.org/node/240 for usage.
